# John's 411

Private safety community for independent escorts.

## How to deploy (super simple!)

1. Upload this whole folder to GitHub
2. Go to vercel.com → New Project → Import from GitHub
3. Click Deploy — done!

## Files in this project

- `src/App.jsx` — the whole website
- `src/index.js` — entry point (don't touch)
- `public/index.html` — the page shell (don't touch)
- `package.json` — app settings (don't touch)
- `vercel.json` — Vercel settings (don't touch)
